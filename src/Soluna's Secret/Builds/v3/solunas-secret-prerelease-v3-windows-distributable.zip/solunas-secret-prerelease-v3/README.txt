Greetings.

Thank you for volunteering to playtest Soluna's Secret.
Please bear in mind that this is an early version that may not be representative
of the final product... and that final product is a demo. There will be bugs.
It's your job to help me find and squash those bugs before the game is released
to the general voting public. I honour your participation.

Good luck.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This game was made by Callum John (@ItsSeaJay) for #LOWREZJAM 2017 in Unity.
Do not redistribute.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Controls:
Mouse          - Look
W, S, A, and D - Move forwards, backwards, left, and right respectively.
E/Left Click   - Interact
F/Right Click  - Toggle Lantern (Once Held)
Space          - Jump
Shift          - Run
Escape         - Quit

Controls can be rebound using the launcher.
An aspect ratio of 4:3 is recommended.
